package com.example.demo;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private String[] imagePaths = {
            "img1.jpg",
            "img2.jpg",
            "img3.jpg",
            "img4.jpg",
            "img5.jpg",
            "img6.jpg",
            "img7.jpg",
    };

    private ImageView fullSizeImageView;
    private int currentIndex = -1;

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        for (int i = 0; i < imagePaths.length; i++) {
            ImageView thumbnailImageView = createThumbnailImageView(imagePaths[i]);
            int index = i;
            thumbnailImageView.setOnMouseClicked(event -> showFullSizeImage(index));
            gridPane.add(thumbnailImageView, i % 4, i / 4);
        }

        StackPane root = new StackPane(gridPane);
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Gallery");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private ImageView createThumbnailImageView(String imagePath) {
        ImageView imageView = new ImageView(new Image(imagePath));
        imageView.setFitWidth(200);
        imageView.setFitHeight(200);
        return imageView;
    }

    private void showFullSizeImage(int index) {
        Stage fullSizeStage = new Stage();
        fullSizeImageView = new ImageView(new Image(imagePaths[index]));
        StackPane fullSizePane = new StackPane(fullSizeImageView);

        Button backButton = new Button("Back");
        backButton.setOnAction(event -> fullSizeStage.close());

        Button prevButton = new Button("Previous");
        prevButton.setOnAction(event -> navigate(-1));

        Button nextButton = new Button("Next");
        nextButton.setOnAction(event -> navigate(1));

        StackPane.setAlignment(backButton, javafx.geometry.Pos.BOTTOM_LEFT);
        StackPane.setAlignment(prevButton, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setAlignment(nextButton, javafx.geometry.Pos.BOTTOM_RIGHT);

        StackPane.setMargin(backButton, new Insets(0, 10, 10, 0));
        StackPane.setMargin(nextButton, new Insets(0, 0, 10, 10));

        StackPane fullSizeWithButtons = new StackPane(fullSizePane, backButton, prevButton, nextButton);

        Scene fullSizeScene = new Scene(fullSizeWithButtons);
        fullSizeStage.setScene(fullSizeScene);
        fullSizeStage.show();

        currentIndex = index;
    }

    private void navigate(int step) {
        if (currentIndex + step >= 0 && currentIndex + step < imagePaths.length) {
            currentIndex += step;
            fullSizeImageView.setImage(new Image(imagePaths[currentIndex]));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
